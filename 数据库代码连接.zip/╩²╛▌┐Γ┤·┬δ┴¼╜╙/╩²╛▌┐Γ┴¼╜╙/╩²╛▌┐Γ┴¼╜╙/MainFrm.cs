﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace 数据库连接
{
    public partial class MainFrm : Form
    {
        public MainFrm()
        {
            InitializeComponent();
        }

        private void 查询学生ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //查询学生
         FrmstuQue frm =   new FrmstuQue();

         frm.MdiParent = this;
         
         frm.Show(); //显示窗体


        }

        private void 教师ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 添加学生ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //打开添加学生,村塾到数据量
            FrmStudentAdd frm = new FrmStudentAdd();

            frm.MdiParent = this;

            frm.Show();//显示添加学生


        }

        private void 查询课程ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCoures_Q frm = new FrmCoures_Q();

            frm.MdiParent = this;

            frm.Show();
        }

        private void 统计ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //显示
            frmStat frm = new frmStat();
            frm.MdiParent = this;
            frm.Show();
        }

        private void MainFrm_Load(object sender, EventArgs e)
        {
            this.Text = "学生管理系统，当前登录的用户为：" + Frmlogin.loginName;
            if (Frmlogin.loginName == "1906200072")
            {
                统计信息ToolStripMenuItem.Visible = false;
            }
        }

        private void 学生管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 查询教师信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmteacher_Q frm = new Frmteacher_Q();
            frm.MdiParent = this;
            frm.Show();
        }

        private void 添加教师ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmteacher_add frm = new Frmteacher_add();

            frm.MdiParent = this;

            frm.Show();//显示添加学生

        }

        private void 删除教师ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 教师个人信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmteacher_info2 frm = new Frmteacher_info2();

            frm.MdiParent = this;

            frm.Show();//显示教师信息
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 查询SCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_sc_Q frm = new Frm_sc_Q();

            frm.MdiParent = this;

            frm.Show();
        }

        private void 添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmsc_add frm = new Frmsc_add();

            frm.MdiParent = this;

            frm.Show();
        }

        private void 修改ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmsc_modify frm = new Frmsc_modify();

            frm.MdiParent = this;

            frm.Show();
        }
    }
}
