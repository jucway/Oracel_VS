﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 数据库连接
{
    public partial class Frmteacher_Q : Form
    {
        public Frmteacher_Q()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.dataGridView1.DataSource = teacher.Selectteacher(this.textBox1.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
 

           // teacher t = (teacher)row.DataBoundItem; //每一行强制转换为课程类对象
            if (this.dataGridView1.Rows.Count == 0) return;
            if (e.RowIndex < 0) return;
            DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
            try
            {

                if (e.ColumnIndex == 6)
                {
                    //表示用户点击了删除按钮
                    string tno = row.Cells[0].Value.ToString();
                    if (teacher.Deleteteacher(tno) == 1)
                    {
                        MessageBox.Show("delete success");
                        //this.dataGridView1.Rows.Remove(row);//出问题
                    }
                    else
                        MessageBox.Show("没有找到数据");


                }


                else if (e.ColumnIndex == 5)
                {
                    //表示用户点击了修改按钮
                    teacher t = (teacher)row.DataBoundItem;
                    Frmteacher_modify frm = new Frmteacher_modify();
                    frm.tbtno.Text = t.tno;
                    frm.tbtname.Text = t.tname;
                    frm.tbtposition.Text = t.tposition;
                    frm.tbtsalary.Text = t.tsalary.ToString();
                    frm.tbtpwd.Text = t.pwd;
                    frm.ShowDialog();



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
