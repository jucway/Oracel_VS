﻿namespace 数据库连接
{
    partial class Frmteacher_add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbtno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbtname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbtposition = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbtsalary = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbtpwd = new System.Windows.Forms.TextBox();
            this.添加 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(64, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "职工号";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tbtno
            // 
            this.tbtno.Location = new System.Drawing.Point(135, 40);
            this.tbtno.Name = "tbtno";
            this.tbtno.Size = new System.Drawing.Size(149, 25);
            this.tbtno.TabIndex = 1;
            this.tbtno.TextChanged += new System.EventHandler(this.tbtno_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(64, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "姓名";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // tbtname
            // 
            this.tbtname.Location = new System.Drawing.Point(135, 81);
            this.tbtname.Name = "tbtname";
            this.tbtname.Size = new System.Drawing.Size(149, 25);
            this.tbtname.TabIndex = 1;
            this.tbtname.TextChanged += new System.EventHandler(this.tbtname_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(64, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "职务";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // tbtposition
            // 
            this.tbtposition.Location = new System.Drawing.Point(135, 124);
            this.tbtposition.Name = "tbtposition";
            this.tbtposition.Size = new System.Drawing.Size(149, 25);
            this.tbtposition.TabIndex = 1;
            this.tbtposition.TextChanged += new System.EventHandler(this.tbtposition_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(64, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "月薪";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // tbtsalary
            // 
            this.tbtsalary.Location = new System.Drawing.Point(135, 166);
            this.tbtsalary.Name = "tbtsalary";
            this.tbtsalary.Size = new System.Drawing.Size(149, 25);
            this.tbtsalary.TabIndex = 1;
            this.tbtsalary.TextChanged += new System.EventHandler(this.tbtsalary_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(64, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "密码";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // tbtpwd
            // 
            this.tbtpwd.Location = new System.Drawing.Point(135, 212);
            this.tbtpwd.Name = "tbtpwd";
            this.tbtpwd.Size = new System.Drawing.Size(149, 25);
            this.tbtpwd.TabIndex = 1;
            this.tbtpwd.TextChanged += new System.EventHandler(this.tbtpwd_TextChanged);
            // 
            // 添加
            // 
            this.添加.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.添加.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.添加.Location = new System.Drawing.Point(347, 113);
            this.添加.Name = "添加";
            this.添加.Size = new System.Drawing.Size(102, 44);
            this.添加.TabIndex = 2;
            this.添加.Text = "添加";
            this.添加.UseVisualStyleBackColor = false;
            this.添加.Click += new System.EventHandler(this.添加_Click);
            // 
            // Frmteacher_add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(512, 292);
            this.Controls.Add(this.添加);
            this.Controls.Add(this.tbtpwd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbtsalary);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbtposition);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbtname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbtno);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Name = "Frmteacher_add";
            this.Text = "Frmteacher_add";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox tbtno;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox tbtname;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox tbtposition;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox tbtsalary;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox tbtpwd;
        private System.Windows.Forms.Button 添加;
    }
}