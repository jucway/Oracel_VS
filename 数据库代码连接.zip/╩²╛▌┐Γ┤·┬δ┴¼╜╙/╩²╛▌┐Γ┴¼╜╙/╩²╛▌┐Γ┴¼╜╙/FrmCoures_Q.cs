﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace 数据库连接
{
    public partial class FrmCoures_Q : Form
    {
        public FrmCoures_Q()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //根据输入的课程名称查找课程列表

            //将捕获到的数据绑定到dataGridView 的数据源上
            try
            {
                this.dataGridView1.DataSource = Course.SelectCourse(this.textBox1.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {



            //if (dataGridView1.SelectedRows.Count == 0) return;

            //if (MessageBox.Show("是否要删除数据", "请再次确认信息", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            //    return;

            //DataGridViewRow row = dataGridView1.SelectedRows[0];

            //string cno = row.Cells[0].Value.ToString();

            //string sql = string.Format("delete from cname where cname = '{0}'", cno);

            //OracleConnection con = new OracleConnection(Program.strCon);
            //try
            //{
            //    con.Open();

            //    OracleCommand cmd = new OracleCommand(sql, con);

            //    cmd.ExecuteNonQuery();//根据学号删除学生
            //    if (cmd.ExecuteNonQuery() == 1)
            //    {
            //        MessageBox.Show("删除成功！");
            //        dataGridView1.Rows.Remove(row);
            //    }
            //    else MessageBox.Show("删除失败，检查输入是否正确或者数据库没有要查找项目！");
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);

            //}

            //finally
            //{
            //    con.Close();
            //}
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           // MessageBox.Show(e.RowIndex.ToString() + "," + e.ColumnIndex.ToString());

            if (e.RowIndex < 0) return;

            DataGridViewRow  row = dataGridView1.Rows[e.RowIndex];

            Course c = (Course)row.DataBoundItem; //每一行强制转换为课程类对象

            try
            {
                if (e.ColumnIndex == 3)//点击删除按钮
                {
                    if (MessageBox.Show("是否要删除选中内容!", "请再次确认操作！", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                        return;
                    if (Course.DeleteCourse(c.Cno) == 1) //删除成功

                        MessageBox.Show("删除成功！");

                    else MessageBox.Show("删除不成功，请检查一下操作是否正确，或数据库是否已经连接！");


                }


                else if (e.ColumnIndex == 4)
                {
                    FrmCourseUpdate frm = new FrmCourseUpdate();

                    //填写修改信息填写到对应的文本框
                    frm.tbcno.Text = c.Cno;

                    frm.tbcname.Text = c.Cname;

                    frm.tbccredit.Text = c.Ccredit.ToString();

                    
                    frm.ShowDialog(this);



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
