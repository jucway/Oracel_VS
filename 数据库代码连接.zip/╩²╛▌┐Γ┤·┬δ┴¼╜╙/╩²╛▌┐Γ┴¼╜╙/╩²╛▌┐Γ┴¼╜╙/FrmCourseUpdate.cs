﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 数据库连接
{
    public partial class FrmCourseUpdate : Form
    {
        public FrmCourseUpdate()
        {
            InitializeComponent();
        }

        private void 修改学生信息_Click(object sender, EventArgs e)
        {
            Course c = new Course();

            c.Cno = this.tbcno.Text;

            c.Cname = tbcname.Text;

            c.Ccredit = Convert.ToInt16(tbccredit.Text);

            try
            {
                if (Course.UpdateCourse(c) == 1)
                {
                    MessageBox.Show("修改成功！");
                    this.Close();
                }
                else MessageBox.Show("没有找到！");


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            }
       
    }
}
