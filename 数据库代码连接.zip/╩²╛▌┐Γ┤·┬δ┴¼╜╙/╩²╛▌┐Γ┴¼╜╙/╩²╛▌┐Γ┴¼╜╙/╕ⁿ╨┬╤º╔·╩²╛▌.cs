﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace 数据库连接
{
    public partial class FrmStuUpdate : Form
    {
        public FrmStuUpdate()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //修改学生信息
            string sql = string.Format("update student set sname = '{0}' , ssex = '{1}' , ssno = '{2}' , ssage = '{3}' , pwd = '{4}'", tbsname.Text, tbssex.Text, tbssno.Text, tbspwd.Text);

            //连接到数据库
            OracleConnection con = new OracleConnection(Program.strCon);
            try
            {
                con.Open();

                OracleCommand cmd = new OracleCommand(sql, con);

                cmd.ExecuteNonQuery();//根据学号删除学生
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("修改成功！");
                    this.Close();
                }
                else MessageBox.Show("修改失败，检查输入是否正确或者数据库没有要修改项目！");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

            finally
            {
                con.Close();
            }

        }

        private void 更新学生数据_Load(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void tbsage_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbssno_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void tbssex_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tbsname_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tbspwd_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
