﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace 数据库连接
{
    public partial class FrmstuQue : Form
    {
        public FrmstuQue()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //访问数据库
            //string sql = this.textBox1.Text;
            //string sql = "select sno, sname ,ssex , sage,sdept from student where sname like  '"
            string sql = String.Format("select sname,ssex,sno, sage ,pwd  from student where sname like '{0}%'",textBox1.Text);

            OracleConnection con = new OracleConnection("Data Source=(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1522)) (CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = zcw.domain)));User Id=zcw_;Password=z123");
            try
            {
                con.Open();

            OracleCommand cmd = new OracleCommand(sql, con);

            OracleDataReader odr = cmd.ExecuteReader();
      
                if (odr.HasRows)
                {
                    BindingSource bs = new BindingSource();

                    bs.DataSource = odr;

                    dataGridView1.DataSource = bs;


                }
                else
                    dataGridView1.DataSource = null;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //删除学生
            if (dataGridView1.SelectedRows.Count == 0) return;

            if (MessageBox.Show("是否要删除数据", "请再次确认信息", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                return;

            DataGridViewRow row = dataGridView1.SelectedRows[0];

            string sno = row.Cells[0].Value.ToString();

            string sql = string.Format("delete from student where sname = '{0}'", sno);

            OracleConnection con = new OracleConnection(Program.strCon);
            try
            {
                con.Open();

                OracleCommand cmd = new OracleCommand(sql, con);

                cmd.ExecuteNonQuery();//根据学号删除学生
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("删除成功！");
                    dataGridView1.Rows.Remove(row);
                }
                else MessageBox.Show("删除失败，检查输入是否正确或者数据库没有要查找项目！");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

            finally
            {
                con.Close();
            }
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //打开修改学生信息的窗体，修改学生信息
            //显示修改
            if (dataGridView1.SelectedRows.Count == 0) return; //用户选择行

            FrmStuUpdate frm = new FrmStuUpdate();

            DataGridViewRow row = dataGridView1.SelectedRows[0];

            frm.tbsname.Text = row.Cells[0].Value.ToString();

            frm.tbssex.Text = row.Cells[1].Value.ToString();

            frm.tbssno.Text = row.Cells[2].Value.ToString();

            frm.tbsage.Text = row.Cells[3].Value.ToString();

            frm.tbspwd.Text = row.Cells[4].Value.ToString();


            frm.ShowDialog(this);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
