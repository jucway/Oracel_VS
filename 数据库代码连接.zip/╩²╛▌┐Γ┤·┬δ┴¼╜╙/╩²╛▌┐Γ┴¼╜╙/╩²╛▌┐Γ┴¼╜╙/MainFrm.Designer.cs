﻿namespace 数据库连接
{
    partial class MainFrm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.学生管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询学生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加学生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教师ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询教师信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加教师ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教师个人信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询课程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询SCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.统计信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.统计ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.学生管理ToolStripMenuItem,
            this.查询学生ToolStripMenuItem,
            this.教师ToolStripMenuItem,
            this.课程管理ToolStripMenuItem,
            this.统计信息ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(978, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 学生管理ToolStripMenuItem
            // 
            this.学生管理ToolStripMenuItem.Name = "学生管理ToolStripMenuItem";
            this.学生管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.学生管理ToolStripMenuItem.Text = "学生管理";
            this.学生管理ToolStripMenuItem.Click += new System.EventHandler(this.学生管理ToolStripMenuItem_Click);
            // 
            // 查询学生ToolStripMenuItem
            // 
            this.查询学生ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加学生ToolStripMenuItem});
            this.查询学生ToolStripMenuItem.Name = "查询学生ToolStripMenuItem";
            this.查询学生ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.查询学生ToolStripMenuItem.Text = "查询学生";
            this.查询学生ToolStripMenuItem.Click += new System.EventHandler(this.查询学生ToolStripMenuItem_Click);
            // 
            // 添加学生ToolStripMenuItem
            // 
            this.添加学生ToolStripMenuItem.Name = "添加学生ToolStripMenuItem";
            this.添加学生ToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.添加学生ToolStripMenuItem.Text = "添加学生";
            this.添加学生ToolStripMenuItem.Click += new System.EventHandler(this.添加学生ToolStripMenuItem_Click);
            // 
            // 教师ToolStripMenuItem
            // 
            this.教师ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查询教师信息ToolStripMenuItem,
            this.添加教师ToolStripMenuItem,
            this.教师个人信息ToolStripMenuItem});
            this.教师ToolStripMenuItem.Name = "教师ToolStripMenuItem";
            this.教师ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.教师ToolStripMenuItem.Text = "教师管理";
            this.教师ToolStripMenuItem.Click += new System.EventHandler(this.教师ToolStripMenuItem_Click);
            // 
            // 查询教师信息ToolStripMenuItem
            // 
            this.查询教师信息ToolStripMenuItem.Name = "查询教师信息ToolStripMenuItem";
            this.查询教师信息ToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.查询教师信息ToolStripMenuItem.Text = "查询教师信息";
            this.查询教师信息ToolStripMenuItem.Click += new System.EventHandler(this.查询教师信息ToolStripMenuItem_Click);
            // 
            // 添加教师ToolStripMenuItem
            // 
            this.添加教师ToolStripMenuItem.Name = "添加教师ToolStripMenuItem";
            this.添加教师ToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.添加教师ToolStripMenuItem.Text = "添加教师";
            this.添加教师ToolStripMenuItem.Click += new System.EventHandler(this.添加教师ToolStripMenuItem_Click);
            // 
            // 教师个人信息ToolStripMenuItem
            // 
            this.教师个人信息ToolStripMenuItem.Name = "教师个人信息ToolStripMenuItem";
            this.教师个人信息ToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.教师个人信息ToolStripMenuItem.Text = "教师个人信息";
            this.教师个人信息ToolStripMenuItem.Click += new System.EventHandler(this.教师个人信息ToolStripMenuItem_Click);
            // 
            // 课程管理ToolStripMenuItem
            // 
            this.课程管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查询课程ToolStripMenuItem,
            this.查询SCToolStripMenuItem});
            this.课程管理ToolStripMenuItem.Name = "课程管理ToolStripMenuItem";
            this.课程管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.课程管理ToolStripMenuItem.Text = "课程管理";
            // 
            // 查询课程ToolStripMenuItem
            // 
            this.查询课程ToolStripMenuItem.Name = "查询课程ToolStripMenuItem";
            this.查询课程ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.查询课程ToolStripMenuItem.Text = "查询课程";
            this.查询课程ToolStripMenuItem.Click += new System.EventHandler(this.查询课程ToolStripMenuItem_Click);
            // 
            // 查询SCToolStripMenuItem
            // 
            this.查询SCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加ToolStripMenuItem,
            this.修改ToolStripMenuItem,
            this.删除ToolStripMenuItem});
            this.查询SCToolStripMenuItem.Name = "查询SCToolStripMenuItem";
            this.查询SCToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.查询SCToolStripMenuItem.Text = "查询SC";
            this.查询SCToolStripMenuItem.Click += new System.EventHandler(this.查询SCToolStripMenuItem_Click);
            // 
            // 添加ToolStripMenuItem
            // 
            this.添加ToolStripMenuItem.Name = "添加ToolStripMenuItem";
            this.添加ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.添加ToolStripMenuItem.Text = "添加";
            this.添加ToolStripMenuItem.Click += new System.EventHandler(this.添加ToolStripMenuItem_Click);
            // 
            // 修改ToolStripMenuItem
            // 
            this.修改ToolStripMenuItem.Name = "修改ToolStripMenuItem";
            this.修改ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.修改ToolStripMenuItem.Text = "修改";
            this.修改ToolStripMenuItem.Click += new System.EventHandler(this.修改ToolStripMenuItem_Click);
            // 
            // 删除ToolStripMenuItem
            // 
            this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            this.删除ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.删除ToolStripMenuItem.Text = "删除";
            // 
            // 统计信息ToolStripMenuItem
            // 
            this.统计信息ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.统计ToolStripMenuItem});
            this.统计信息ToolStripMenuItem.Name = "统计信息ToolStripMenuItem";
            this.统计信息ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.统计信息ToolStripMenuItem.Text = "统计信息";
            // 
            // 统计ToolStripMenuItem
            // 
            this.统计ToolStripMenuItem.Name = "统计ToolStripMenuItem";
            this.统计ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.统计ToolStripMenuItem.Text = "统计";
            this.统计ToolStripMenuItem.Click += new System.EventHandler(this.统计ToolStripMenuItem_Click);
            // 
            // MainFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::数据库连接.Properties.Resources.Oracle;
            this.ClientSize = new System.Drawing.Size(978, 558);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainFrm";
            this.Text = "数据库连接（学生管理系统）";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainFrm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 学生管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询学生ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教师ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加学生ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询课程ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 统计信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 统计ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询教师信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加教师ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教师个人信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询SCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
    }
}

