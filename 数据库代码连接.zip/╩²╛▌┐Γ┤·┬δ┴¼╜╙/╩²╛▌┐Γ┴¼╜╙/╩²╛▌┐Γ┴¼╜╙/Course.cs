﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
namespace 数据库连接

{
    public class Course
    {
        public string Cno { get; set; }

        public string Cname { get; set; }

        public int Ccredit { get; set; }

        //public string Tno { get; set; }


        public static List<Course> SelectCourse(string Cname)

        {

            List<Course> list = new List<Course>();


            string sql = "select cno, cname ,ccredit from course where cname like :cname";

            OracleParameter[ ] para = new OracleParameter[ ]
            {
                     new OracleParameter(":cname" , OracleDbType.Varchar2, 40)

             };
            para[0].Value = Cname + "%";

            OracleConnection con = new OracleConnection(Program.strCon);

            try
            {

                con.Open();

                OracleCommand cmd = new OracleCommand(sql, con);

                cmd.Parameters.AddRange(para);//添加参数设置

                OracleDataReader odr = cmd.ExecuteReader();//得到阅读器对象之后，读出课程信息

                while (odr.Read())
                {
                    Course c = new Course();//生成课程对象

                    c.Cno = odr.GetString(0);  //c.Cno = odr["cno"] .Tostring()

                    c.Cname = odr.GetString(1);


                    c.Ccredit = odr.GetInt16(2);

                  //  c.Tno = odr.GetString(3);

                    list.Add(c);
                }

            }
            finally
            {
                con.Close();
            }


            return list;



        }
        public static int DeleteCourse(string cno)
        {
            string sql = "delete from course where cno =:cno";
            int res;
        OracleParameter[] para = new OracleParameter[]
        {
                new OracleParameter(":cno" ,OracleDbType.Varchar2,40)

        };
            para[0].Value = cno;
            OracleConnection con = new OracleConnection(Program.strCon);
            try
            {
                con.Open();

                OracleCommand cmd = new OracleCommand(sql, con);

                cmd.Parameters.AddRange(para);

                res = cmd.ExecuteNonQuery(); //执行返回整数
            }
            finally
            {
                con.Close();
            }
            return res;
        }
        //把修改后的课程信息更新到数据库
        public static int UpdateCourse(Course c)
        {
            //课程号没有变化，其他属性发生变化
            string sql = "update course set cname=:cname, ccredit = :ccredit where cno = :cno";
            OracleParameter[] para = new OracleParameter[]
                {
                new OracleParameter(":cname", OracleDbType.Varchar2, 40),

            new OracleParameter(":ccredit", OracleDbType.Int16, 8),

            new OracleParameter(":cno", OracleDbType.Varchar2, 4),

            new OracleParameter(":tno", OracleDbType.Varchar2, 4)
        };
            para[0].Value = c.Cname;
            para[1].Value = c.Cname;
            para[2].Value = c.Cno;

            int res;
            OracleConnection con = new OracleConnection(Program.strCon);
            try
            {
                con.Open();

                OracleCommand cmd = new OracleCommand(sql, con);

                cmd.Parameters.AddRange(para);
                res = cmd.ExecuteNonQuery();
            }

            finally {

                con.Close();

            }



            return res;


        }

    }
}
