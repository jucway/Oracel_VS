﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 数据库连接
{
    public partial class Frmteacher_modify : Form
    {
        public Frmteacher_modify()
        {
            InitializeComponent();
        }

        private void 添加_Click(object sender, EventArgs e)
        {
            teacher t = new teacher();
            t.tno = tbtno.Text;//保持不变的
            t.tname = tbtname.Text;
            t.tposition = tbtposition.Text;
            t.tsalary = Convert.ToInt32(tbtsalary.Text);
            t.pwd = tbtpwd.Text;
            if (teacher.Updateteacher(t) == 1)
                MessageBox.Show("update success");
            else
                MessageBox.Show("可能没有找到记录");
        }
    }
}
