﻿namespace 数据库连接
{
    partial class FrmCourseUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCourseUpdate));
            this.label1 = new System.Windows.Forms.Label();
            this.tbcno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbcname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbccredit = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbtno = new System.Windows.Forms.TextBox();
            this.修改学生信息 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "课程号";
            // 
            // tbcno
            // 
            this.tbcno.Location = new System.Drawing.Point(94, 49);
            this.tbcno.Name = "tbcno";
            this.tbcno.ReadOnly = true;
            this.tbcno.Size = new System.Drawing.Size(100, 25);
            this.tbcno.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "课程名";
            // 
            // tbcname
            // 
            this.tbcname.Location = new System.Drawing.Point(94, 80);
            this.tbcname.Name = "tbcname";
            this.tbcname.Size = new System.Drawing.Size(100, 25);
            this.tbcname.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "学分";
            // 
            // tbccredit
            // 
            this.tbccredit.Location = new System.Drawing.Point(94, 111);
            this.tbccredit.Name = "tbccredit";
            this.tbccredit.Size = new System.Drawing.Size(100, 25);
            this.tbccredit.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "教师编号";
            // 
            // tbtno
            // 
            this.tbtno.Location = new System.Drawing.Point(94, 142);
            this.tbtno.Name = "tbtno";
            this.tbtno.Size = new System.Drawing.Size(100, 25);
            this.tbtno.TabIndex = 1;
            // 
            // 修改学生信息
            // 
            this.修改学生信息.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.修改学生信息.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.修改学生信息.Location = new System.Drawing.Point(316, 111);
            this.修改学生信息.Name = "修改学生信息";
            this.修改学生信息.Size = new System.Drawing.Size(91, 38);
            this.修改学生信息.TabIndex = 2;
            this.修改学生信息.Text = "修改";
            this.修改学生信息.UseVisualStyleBackColor = false;
            this.修改学生信息.Click += new System.EventHandler(this.修改学生信息_Click);
            // 
            // FrmCourseUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 258);
            this.Controls.Add(this.修改学生信息);
            this.Controls.Add(this.tbtno);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbccredit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbcname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbcno);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmCourseUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmCourseUpdate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox tbcno;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox tbcname;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox tbccredit;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox tbtno;
        private System.Windows.Forms.Button 修改学生信息;
    }
}