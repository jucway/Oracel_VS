﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace 数据库连接
{
    class teacherinfo

    {

        public string 职位 { get; set; }

        public int 在任人数 { get; set; }

        public double 平均工资 { get; set; }

        public string 教师工号 { get; set; }

        public string 教师姓名 { get; set; }

        public int 授课学生总人数 { get; set; }

        public static List<teacherinfo> Selectteacherinfo1()

        {

            string sql = "select *from teacherinfo1 where 职位 like :职位";

            OracleParameter[] para = new OracleParameter[] { new OracleParameter(":职位", OracleDbType.Char, 7) };

            para[0].Value = "%";

            //MessageBox.Show(tname+"%");

            List<teacherinfo> list = new List<teacherinfo>();

            //创建链接，打开连接，创建命令对象，执行命令，关闭连接

            //OracleConnection con = new OracleConnection(ConfigurationManager.ConnectionStrings["strCon"].ConnectionString);
            OracleConnection con = new OracleConnection(Program.strCon);

            try

            {

                con.Open();

                OracleCommand cmd = new OracleCommand(sql, con);

                cmd.Parameters.AddRange(para);

                OracleDataReader odr = cmd.ExecuteReader();

                while (odr.Read())

                {

                    teacherinfo s_infon = new teacherinfo();

                    //c.Cno = odr.GetString(0); //ord["cno'].

                    s_infon.职位 = odr["职位"].ToString();

                    //t.tno = odr.GetString(0);

                    s_infon.在任人数 = odr.GetInt32(1);

                    if (odr.IsDBNull(2))

                        s_infon.平均工资 = 0;

                    else

                        s_infon.平均工资 = odr.GetDouble(2);

                    list.Add(s_infon);

                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

            finally

            {

                con.Close();

            }

            return list;

        }

        public static List<teacherinfo> Selectteacherinfo2(string tno)

        {

            string sql = "select *from teacherinfo2 where 教师工号 like :教师工号";

            OracleParameter[] para = new OracleParameter[] { new OracleParameter(":教师工号", OracleDbType.Char, 7) };

            para[0].Value = tno + "%";

            //MessageBox.Show(tname+"%");

            List<teacherinfo> list = new List<teacherinfo>();

            //创建链接，打开连接，创建命令对象，执行命令，关闭连接

            OracleConnection con = new OracleConnection(Program.strCon);

            try

            {

                con.Open();

                OracleCommand cmd = new OracleCommand(sql, con);

                cmd.Parameters.AddRange(para);

                OracleDataReader odr = cmd.ExecuteReader();

                while (odr.Read())

                {

                    teacherinfo s_infon = new teacherinfo();

                    //c.Cno = odr.GetString(0); //ord["cno'].

                    s_infon.教师工号 = odr["教师工号"].ToString();

                    //t.tno = odr.GetString(0);

                    s_infon.教师姓名 = odr.GetString(1);

                    if (odr.IsDBNull(2))

                        s_infon.授课学生总人数 = 0;

                    else

                        s_infon.授课学生总人数 = odr.GetInt32(2);

                    list.Add(s_infon);

                }

            }

            catch (Exception ex)

            {

                MessageBox.Show(ex.Message);

            }

            finally

            {

                con.Close();

            }

            return list;

        }

    }

}

