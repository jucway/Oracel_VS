﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace 数据库连接
{
    public partial class FrmStudentAdd : Form
    {
        public FrmStudentAdd()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //添加学生信息，存到数据库内
            string sql = string.Format("insert into student(sname,ssex,ssno, sage, pwd) values('{0}','{1}','{2}','{3}','{4}')", tbsname.Text, tbssex.Text, tbssno.Text, tbsage.Text,tbspwd.Text);

            //连接到数据库
            OracleConnection con = new OracleConnection(Program.strCon);
            try
            {
                con.Open();

                OracleCommand cmd = new OracleCommand(sql, con);

                cmd.ExecuteNonQuery();//根据学号删除学生
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("添加成功！");
                    
                }
              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

            finally
            {
                con.Close();
            }
        }

        private void tbssno_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmStudentAdd_Load(object sender, EventArgs e)
        {

        }
    }
}
