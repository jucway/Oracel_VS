﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 数据库连接
{
    static class Program
    {
        public static readonly string strCon = "Data Source = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1522))(CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = zcw.domain))); User Id = zcw_; Password=z123";
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Frmlogin frm = new Frmlogin();
            if (frm.ShowDialog() == DialogResult.OK)
            {
                Application.Run(new MainFrm());
            }
            else Application.Exit();//运行解释
        }
    }
}
