﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace 数据库连接
{
    public partial class Frmlogin : Form
    {
        public static string loginName = null;
        public Frmlogin()
        {
            InitializeComponent();
        }

        private void Logon_Click(object sender, EventArgs e)
        {
            //    //判断是否正确登录，真确的用户名和正确的密码
            //    //否则退出
            //    string username = tbUsername.Text;

            //    string pwd = tbpwd.Text;

            //   // string sql = string.Format("select sno ,pwd from student where sno='{0}' , pwd = '{1}'",username ,pwd);
            //    string sql = "select sno,sname from student where sno= :sno and pwd = :pwd";
            //    OracleParameter[] para = new OracleParameter[]
            //        {
            //        new OracleParameter (":sno",OracleDbType.Varchar2,20),
            //        new OracleParameter (":pwd",OracleDbType.Varchar2,20)


            //        };

            //    para[0].Value = username;
            //    para[1].Value = pwd;

            //    OracleConnection con = new OracleConnection(Program.strCon);
            //    try
            //    {
            //        con.Open();

            //    OracleCommand cmd = new OracleCommand(sql, con);
            //        cmd.Parameters.AddRange(para);
            //    OracleDataReader odr = cmd.ExecuteReader();



            //        if (odr.Read())
            //        {
            //            loginName = odr.GetString(0);
            //            this.DialogResult = DialogResult.OK;
            //            MessageBox.Show("登录成功！");
            //        }
            //        else
            //            MessageBox.Show("用户名或者密码错误！");
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.Message);
            //    }
            //    con.Close();
            //}


            if (radioButton1.Checked == true)
            {


                string username = tbUsername.Text;

                string pwd = tbpwd.Text;

                // string sql = string.Format("select sno ,pwd from student where sno='{0}' , pwd = '{1}'",username ,pwd);
                string sql = "select sno,sname from student where sno= :sno and pwd = :pwd";
                OracleParameter[] para = new OracleParameter[]
                    {
                        new OracleParameter (":sno",OracleDbType.Varchar2,20),
                        new OracleParameter (":pwd",OracleDbType.Varchar2,20)


                    };

                para[0].Value = username;
                para[1].Value = pwd;

                OracleConnection con = new OracleConnection(Program.strCon);
                try
                {
                    con.Open();

                    OracleCommand cmd = new OracleCommand(sql, con);
                    cmd.Parameters.AddRange(para);
                    OracleDataReader odr = cmd.ExecuteReader();



                    if (odr.Read())
                    {
                        loginName = odr.GetString(0);
                        this.DialogResult = DialogResult.OK;
                        MessageBox.Show("当前为学生登录，登录成功！");
                    }
                    else
                        MessageBox.Show("用户名或者密码错误！");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                con.Close();
            }

            else
            {


                // 教师
                string sql = "select *from teacher where tno=:tno and pwd=:pwd";
                string username = tbUsername.Text;

                string pwd = tbpwd.Text;

                OracleParameter[] para = new OracleParameter[]
                    {
                        new OracleParameter (":tno",OracleDbType.Varchar2,20),
                        new OracleParameter (":pwd",OracleDbType.Varchar2,20)


                    };

                para[0].Value = username;
                para[1].Value = pwd;

                OracleConnection con = new OracleConnection(Program.strCon);
                try
                {
                    con.Open();

                    OracleCommand cmd = new OracleCommand(sql, con);
                    cmd.Parameters.AddRange(para);
                    OracleDataReader odr = cmd.ExecuteReader();



                    if (odr.Read())
                    {
                        loginName = odr.GetString(0);
                        this.DialogResult = DialogResult.OK;
                        MessageBox.Show(" 当前为教师登录，登录成功！");
                    }
                    else
                        MessageBox.Show("用户名或者密码错误！");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                con.Close();
            }
        }
    }
}
