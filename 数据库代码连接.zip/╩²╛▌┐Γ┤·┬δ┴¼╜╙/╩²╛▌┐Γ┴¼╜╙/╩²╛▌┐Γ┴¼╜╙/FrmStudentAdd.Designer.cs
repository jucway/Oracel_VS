﻿namespace 数据库连接
{
    partial class FrmStudentAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmStudentAdd));
            this.tbspwd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbsage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbssno = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbssex = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbsname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbspwd
            // 
            this.tbspwd.Location = new System.Drawing.Point(102, 211);
            this.tbspwd.Name = "tbspwd";
            this.tbspwd.Size = new System.Drawing.Size(157, 25);
            this.tbspwd.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(37, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 21);
            this.label5.TabIndex = 8;
            this.label5.Text = "密码";
            // 
            // tbsage
            // 
            this.tbsage.Location = new System.Drawing.Point(102, 169);
            this.tbsage.Name = "tbsage";
            this.tbsage.Size = new System.Drawing.Size(157, 25);
            this.tbsage.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(37, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 21);
            this.label4.TabIndex = 9;
            this.label4.Text = "年龄";
            // 
            // tbssno
            // 
            this.tbssno.Location = new System.Drawing.Point(102, 127);
            this.tbssno.Name = "tbssno";
            this.tbssno.Size = new System.Drawing.Size(157, 25);
            this.tbssno.TabIndex = 14;
            this.tbssno.TextChanged += new System.EventHandler(this.tbssno_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(37, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 21);
            this.label3.TabIndex = 10;
            this.label3.Text = "学号";
            // 
            // tbssex
            // 
            this.tbssex.Location = new System.Drawing.Point(102, 85);
            this.tbssex.Name = "tbssex";
            this.tbssex.Size = new System.Drawing.Size(157, 25);
            this.tbssex.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(37, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 21);
            this.label2.TabIndex = 11;
            this.label2.Text = "性别";
            // 
            // tbsname
            // 
            this.tbsname.Location = new System.Drawing.Point(102, 43);
            this.tbsname.Name = "tbsname";
            this.tbsname.Size = new System.Drawing.Size(157, 25);
            this.tbsname.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(37, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 21);
            this.label1.TabIndex = 6;
            this.label1.Text = "姓名";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Cursor = System.Windows.Forms.Cursors.Default;
            this.button1.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(328, 180);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(167, 44);
            this.button1.TabIndex = 5;
            this.button1.Text = "添加学生信息";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmStudentAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 262);
            this.Controls.Add(this.tbspwd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbsage);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbssno);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbssex);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbsname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmStudentAdd";
            this.Text = "FrmStudentAdd";
            this.Load += new System.EventHandler(this.FrmStudentAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox tbspwd;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox tbsage;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox tbssno;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox tbssex;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox tbsname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}