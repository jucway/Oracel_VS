﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 数据库连接
{
    public partial class Frmteacher_info2 : Form
    {
        public Frmteacher_info2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.dataGridView1.DataSource = studentinfo.Selectstudentinfo(this.textBox1.Text);
            try
            {
                this.dataGridView1.DataSource = teacherinfo.Selectteacherinfo1();
                //this.dataGridView1.DataSource = teacherinfo.Selectteacherinfo2(this.textBox1.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                this.dataGridView1.DataSource = teacherinfo.Selectteacherinfo2(this.textBox1.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
