﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 数据库连接
{
    public partial class Frmsc_add : Form
    {
        public Frmsc_add()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            sc s_c = new sc();
            s_c.sno = tbsno.Text;
            s_c.cno = tbcno.Text;
            s_c.grade = Convert.ToInt32(tbgrade.Text);
            //把课程c放入数据库
            if (sc.Insertsc(s_c) == 1)
            {
                MessageBox.Show("insert success");
            }
        }

        private void tbgrade_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void tbsno_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tbcno_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
