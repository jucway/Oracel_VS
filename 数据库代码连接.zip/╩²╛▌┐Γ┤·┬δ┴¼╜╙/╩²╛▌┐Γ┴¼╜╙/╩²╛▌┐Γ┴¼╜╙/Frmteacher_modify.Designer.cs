﻿namespace 数据库连接
{
    partial class Frmteacher_modify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmteacher_modify));
            this.添加 = new System.Windows.Forms.Button();
            this.tbtpwd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbtsalary = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbtposition = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbtname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbtno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // 添加
            // 
            this.添加.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.添加.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.添加.Location = new System.Drawing.Point(394, 137);
            this.添加.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.添加.Name = "添加";
            this.添加.Size = new System.Drawing.Size(125, 59);
            this.添加.TabIndex = 13;
            this.添加.Text = "修改";
            this.添加.UseVisualStyleBackColor = false;
            this.添加.Click += new System.EventHandler(this.添加_Click);
            // 
            // tbtpwd
            // 
            this.tbtpwd.Location = new System.Drawing.Point(145, 270);
            this.tbtpwd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbtpwd.Name = "tbtpwd";
            this.tbtpwd.Size = new System.Drawing.Size(181, 31);
            this.tbtpwd.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(59, 274);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 21);
            this.label5.TabIndex = 3;
            this.label5.Text = "密码";
            // 
            // tbtsalary
            // 
            this.tbtsalary.Location = new System.Drawing.Point(145, 209);
            this.tbtsalary.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbtsalary.Name = "tbtsalary";
            this.tbtsalary.Size = new System.Drawing.Size(181, 31);
            this.tbtsalary.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(59, 213);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 21);
            this.label4.TabIndex = 4;
            this.label4.Text = "月薪";
            // 
            // tbtposition
            // 
            this.tbtposition.Location = new System.Drawing.Point(145, 153);
            this.tbtposition.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbtposition.Name = "tbtposition";
            this.tbtposition.Size = new System.Drawing.Size(181, 31);
            this.tbtposition.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(59, 157);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 21);
            this.label3.TabIndex = 5;
            this.label3.Text = "职务";
            // 
            // tbtname
            // 
            this.tbtname.Location = new System.Drawing.Point(145, 95);
            this.tbtname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbtname.Name = "tbtname";
            this.tbtname.Size = new System.Drawing.Size(181, 31);
            this.tbtname.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(59, 100);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 21);
            this.label2.TabIndex = 6;
            this.label2.Text = "姓名";
            // 
            // tbtno
            // 
            this.tbtno.Location = new System.Drawing.Point(145, 41);
            this.tbtno.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbtno.Name = "tbtno";
            this.tbtno.Size = new System.Drawing.Size(181, 31);
            this.tbtno.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(59, 45);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 21);
            this.label1.TabIndex = 7;
            this.label1.Text = "职工号";
            // 
            // Frmteacher_modify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 345);
            this.Controls.Add(this.添加);
            this.Controls.Add(this.tbtpwd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbtsalary);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbtposition);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbtname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbtno);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("华文楷体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Frmteacher_modify";
            this.Text = "Frmteacher_modify";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button 添加;
        public System.Windows.Forms.TextBox tbtpwd;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox tbtsalary;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox tbtposition;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox tbtname;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox tbtno;
        private System.Windows.Forms.Label label1;
    }
}